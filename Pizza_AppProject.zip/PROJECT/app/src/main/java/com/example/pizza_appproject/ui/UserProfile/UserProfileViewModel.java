package com.example.pizza_appproject.ui.UserProfile;

import androidx.lifecycle.ViewModel;

public class UserProfileViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}