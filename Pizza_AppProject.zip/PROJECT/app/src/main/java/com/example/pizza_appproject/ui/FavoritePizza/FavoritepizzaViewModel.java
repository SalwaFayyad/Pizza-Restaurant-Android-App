package com.example.pizza_appproject.ui.FavoritePizza;

import androidx.lifecycle.ViewModel;

public class FavoritepizzaViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}